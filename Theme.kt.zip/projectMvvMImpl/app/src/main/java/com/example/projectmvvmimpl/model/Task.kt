data class Task(
    val id: String? = null,
    val title: String,
    var isCompleted: Boolean = false
)