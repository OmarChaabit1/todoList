//package com.example.projectmvvmimpl.ui.components
//
//import Task
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.material3.Card
//import androidx.compose.runtime.*
//import androidx.compose.foundation.*
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.filled.*
//import androidx.compose.material3.*
//
//import androidx.compose.ui.*
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.graphics.*
//
//@Composable
//fun TaskItem(
//    task: Task,
//    onEdit: (String) -> Unit,
//    onDelete: () -> Unit
//) {
//    var isEditing by remember { mutableStateOf(false) }
//    var editedText by remember { mutableStateOf(task.title) }
//
//    Card(
//        modifier = Modifier
//            .fillMaxWidth()
//            .padding(vertical = 4.dp),
//        shape = RoundedCornerShape(8.dp)
//    ) {
//        Row(
//            modifier = Modifier
//                .background(Color.LightGray)
//                .padding(16.dp),
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            if (isEditing) {
//                TextField(
//                    value = editedText,
//                    onValueChange = { editedText = it },
//                    modifier = Modifier.weight(1f),
//                    trailingIcon = {
//                        Icon(
//                            imageVector = Icons.Default.Check,
//                            contentDescription = "Save",
//                            modifier = Modifier.clickable {
//                                onEdit(editedText)
//                                isEditing = false
//                            }
//                        )
//                    }
//                )
//            } else {
//                Text(
//                    text = task.title,
//                    modifier = Modifier.weight(1f)
//                )
//            }
//
//            Icon(
//                imageVector = Icons.Default.Edit,
//                contentDescription = "Edit",
//                modifier = Modifier
//                    .clickable { isEditing = true }
//                    .padding(horizontal = 8.dp)
//            )
//            Icon(
//                imageVector = Icons.Default.Delete,
//                contentDescription = "Delete",
//                tint = Color.Red,
//                modifier = Modifier.clickable { onDelete() }
//            )
//        }
//    }
//}