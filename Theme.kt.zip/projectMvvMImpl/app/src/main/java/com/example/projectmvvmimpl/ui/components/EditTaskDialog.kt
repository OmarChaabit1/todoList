// EditTaskDialog.kt
package com.example.projectmvvmimpl

import Task
import androidx.compose.material3.*
import androidx.compose.runtime.Composable

import androidx.compose.runtime.*

@Composable
fun EditTaskDialog(
    task: Task,
    onUpdate: (Task) -> Unit,
    onDismiss: () -> Unit
) {
    var editedTitle by remember { mutableStateOf(task.title) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Task") },
        text = {
            OutlinedTextField(
                value = editedTitle,
                onValueChange = { editedTitle = it },
                label = { Text("Task title") }
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    onUpdate(task.copy(title = editedTitle))
                    onDismiss()
                },
                enabled = editedTitle.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}