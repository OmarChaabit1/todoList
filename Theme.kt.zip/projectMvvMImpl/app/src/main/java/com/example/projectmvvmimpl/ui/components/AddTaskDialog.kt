// AddTaskDialog.kt
package com.example.projectmvvmimpl

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

import androidx.compose.runtime.*

@Composable
fun AddTaskDialog(
    onAddTask: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var taskTitle by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Task") },
        text = {
            OutlinedTextField(
                value = taskTitle,
                onValueChange = { taskTitle = it },
                label = { Text("Task title") }
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    onAddTask(taskTitle)
                    onDismiss()
                },
                enabled = taskTitle.isNotBlank()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}