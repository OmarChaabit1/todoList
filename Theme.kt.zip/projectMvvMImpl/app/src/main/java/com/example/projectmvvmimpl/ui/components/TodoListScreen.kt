//package com.example.projectmvvmimpl.screens
//
//import androidx.compose.runtime.*
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.unit.dp
//import Task
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.lazy.LazyColumn
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.filled.Add
//import androidx.compose.material3.*
//import com.example.projectmvvmimpl.AddTaskDialog
//import com.example.projectmvvmimpl.TaskCard
//import com.example.projectmvvmimpl.viewmodel.TaskViewModel
//
//
//@Composable
//fun TodoListScreen(viewModel: TaskViewModel) {
//    val tasks = viewModel.tasks
//    val errorMessage by viewModel.errorMessage
//
//    TaskListScreen(
//        tasks = tasks,
//        errorMessage = errorMessage,
//        onAddTask = { title -> viewModel.addTask(title) },
//        onUpdateTask = { task -> viewModel.updateTask(task) },
//        onDeleteTask = { taskId -> viewModel.deleteTask(taskId) }
//    )
//}
//
//@Composable
//fun TaskListScreen(
//    tasks: List<Task>,
//    errorMessage: String,
//    onAddTask: (String) -> Unit,
//    onUpdateTask: (Task) -> Unit,
//    onDeleteTask: (Int) -> Unit
//) {
//    var showAddDialog by remember { mutableStateOf(false) }
//
//    Scaffold(
//        floatingActionButton = {
//            FloatingActionButton(
//                onClick = { showAddDialog = true },
//                containerColor = MaterialTheme.colorScheme.primary
//            ) {
//                Icon(Icons.Filled.Add, "Add Task")
//            }
//        }
//    ) { padding ->
//        Column(modifier = Modifier.padding(padding)) {
//            if (errorMessage.isNotEmpty()) {
//                Text(
//                    text = errorMessage,
//                    color = MaterialTheme.colorScheme.error,
//                    modifier = Modifier.padding(16.dp)
//                )
//            }
//
//            if (tasks.isEmpty()) {
//                ""
////                EmptyState()
//            } else {
//                LazyColumn(modifier = Modifier.weight(1f)) {
//                    items(tasks) { task ->
//                        TaskCard(
//                            task = task,
//                            onUpdate = onUpdateTask,
//                            onDelete = { onDeleteTask(it) },
//                            modifier = Modifier.padding(8.dp)
//                        )
//                        Spacer(modifier = Modifier.height(8.dp))
//                    }
//                }
//            }
//        }
//    }
//
//    if (showAddDialog) {
//        AddTaskDialog(
//            onAddTask = onAddTask,
//            onDismiss = { showAddDialog = false }
//        )
//    }
//}