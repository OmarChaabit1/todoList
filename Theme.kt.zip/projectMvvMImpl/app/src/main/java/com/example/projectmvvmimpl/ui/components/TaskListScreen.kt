//package com.example.projectmvvmimpl.ui.components
//
//
//
//import androidx.compose.runtime.*
//import androidx.compose.ui.Modifier
//import Task
//import androidx.compose.material3.FloatingActionButton
//import androidx.compose.material3.MaterialTheme
//import androidx.compose.material3.Scaffold
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.lazy.LazyColumn
//import androidx.compose.foundation.lazy.items
//import androidx.compose.material.icons.*
//import androidx.compose.material.icons.filled.*
//import androidx.compose.material3.*
//import androidx.compose.ui.unit.*
//import com.example.projectmvvmimpl.AddTaskDialog
//import com.example.projectmvvmimpl.TaskCard
//import com.example.projetmvvmimpl.ui.components.EmptyState
//
//@Composable
//fun TaskListScreen(
//    tasks: List<Task>,
//    errorMessage: String,
//    onAddTask: (String) -> Unit,
//    onUpdateTask: (Task) -> Unit,
//    onDeleteTask: (String) -> Unit
//) {
//    var showAddDialog by remember { mutableStateOf(false) }
//
//    Scaffold(
//        floatingActionButton = {
//            FloatingActionButton(
//                onClick = { showAddDialog = true },
//                containerColor = MaterialTheme.colorScheme.primary
//            ) {
//                Icon(Icons.Filled.Add, "Add Task")
//            }
//        }
//    ) { padding ->
//        Column(modifier = Modifier.padding(padding)) {
////            if (errorMessage.isNotEmpty()) {
////                ErrorMessage(message = errorMessage)
////            }
//
//            if (tasks.isEmpty()) {
//                EmptyState()
//            } else {
//                LazyColumn(modifier = Modifier.weight(1f)) {
//                    items(tasks) { task ->
//                        TaskCard(
//                            task = task,
//                            onUpdate = onUpdateTask,
//                            onDelete = { onDeleteTask(it.toString()) },
//                            modifier = Modifier.padding(8.dp)
//                        )
//                    }
//                }
//            }
//        }
//    }
//
//    if (showAddDialog) {
//        AddTaskDialog(
//            onAddTask = onAddTask,
//            onDismiss = { showAddDialog = false }
//        )
//    }
//}