//// TaskCard.kt
//package com.example.projectmvvmimpl
//
//import androidx.compose.runtime.*
//import androidx.compose.ui.Modifier
//import Task
//import androidx.compose.foundation.layout.*
//import androidx.compose.material.icons.*
//import androidx.compose.material.icons.filled.*
//import androidx.compose.material3.*
//import androidx.compose.ui.*
//import androidx.compose.ui.unit.*
//
//@Composable
//fun TaskCard(
//    task: Int,
//    onUpdate: (Task) -> Unit,
//    onDelete: (String) -> Unit,
//    modifier: Modifier = Modifier
//) {
//    var showEditDialog by remember { mutableStateOf(false) }
//    var showDeleteDialog by remember { mutableStateOf(false) }
//
//    ElevatedCard(modifier = modifier) {
//        Row(
//            modifier = Modifier.padding(16.dp),
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            Checkbox(
//                checked = task.isCompleted,
//                onCheckedChange = { onUpdate(task.copy(isCompleted = it)) }
//            )
//
//            Text(
//                text = task.title,
//                modifier = Modifier.weight(1f),
//                style = MaterialTheme.typography.bodyLarge
//            )
//
//            IconButton(onClick = { showEditDialog = true }) {
//                Icon(Icons.Default.Edit, "Edit")
//            }
//
//            IconButton(onClick = { showDeleteDialog = true }) {
//                Icon(Icons.Default.Delete, "Delete")
//            }
//        }
//    }
//
//    if (showEditDialog) {
//        EditTaskDialog(
//            task = task,
//            onUpdate = onUpdate,
//            onDismiss = { showEditDialog = false }
//        )
//    }
//
//    if (showDeleteDialog) {
//        DeleteConfirmationDialog(
//            task = task,
//            onConfirm = onDelete,
//            onDismiss = { showDeleteDialog = false }
//        )
//    }
//}