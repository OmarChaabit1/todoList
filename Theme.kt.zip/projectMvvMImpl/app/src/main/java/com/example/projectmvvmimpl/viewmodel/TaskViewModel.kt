package com.example.projectmvvmimpl.viewmodel

import Task
import androidx.compose.runtime.*
import androidx.lifecycle.*
import com.example.projectmvvmimpl.TaskRepository
import kotlinx.coroutines.*

class TaskViewModel : ViewModel() {
    private val repository = TaskRepository()
    val tasks = mutableStateListOf<Task>()
    val errorMessage = mutableStateOf("")

    init {
        loadTasks()
    }

    fun loadTasks() {
        viewModelScope.launch {
            try {
                tasks.clear()
                tasks.addAll(repository.getAllTasks())
            } catch (e: Exception) {
                errorMessage.value = "Error loading tasks: ${e.message}"
            }
        }
    }

    fun addTask(title: String) {
        viewModelScope.launch {
            try {
                val newTask = repository.addTask(title)
                tasks.add(newTask)
            } catch (e: Exception) {
                errorMessage.value = "Error adding task: ${e.message}"
            }
        }
    }

    fun updateTask(task: Task) {
        viewModelScope.launch {
            try {
                val updatedTask = repository.updateTask(task)
                val index = tasks.indexOfFirst { it.id == updatedTask.id }
                if (index != -1) tasks[index] = updatedTask
            } catch (e: Exception) {
                errorMessage.value = "Error updating task: ${e.message}"
            }
        }
    }

    fun deleteTask(task: Task) {
        viewModelScope.launch {
            try {
                repository.deleteTask(task.id!!)
                tasks.remove(task)
            } catch (e: Exception) {
                errorMessage.value = "Error deleting task: ${e.message}"
            }
        }
    }
}