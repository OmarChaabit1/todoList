package com.example.projectmvvmimpl.ui.theme

import Task
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.*
import androidx.compose.material3.Card
import androidx.compose.runtime.*
import androidx.compose.material.icons.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*

import androidx.compose.ui.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape

import com.example.projectmvvmimpl.viewmodel.*

class MainActivity : ComponentActivity() {
    private val viewModel: TaskViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProjectMvvmImplTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TaskListScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun TaskListScreen(viewModel: TaskViewModel) {
    var newTaskText by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        // Error message
        if (viewModel.errorMessage.value.isNotEmpty()) {
            Text(
                text = viewModel.errorMessage.value,
                color = Color.Red,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        // Task list
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(viewModel.tasks) { task ->
                TaskItem(
                    task = task,
                    onEdit = { newTitle ->
                        viewModel.updateTask(task.copy(title = newTitle))
                    },
                    onDelete = { viewModel.deleteTask(task) }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        // Add task input
        TaskInput(
            value = newTaskText,
            onValueChange = { newTaskText = it },
            onSubmit = {
                if (newTaskText.isNotBlank()) {
                    viewModel.addTask(newTaskText)
                    newTaskText = ""
                }
            }
        )
    }
}

@Composable
fun TaskInput(
    value: String,
    onValueChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        TextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Add new task") },
            singleLine = true
        )

        Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Add Task",
            modifier = Modifier
                .clickable(onClick = onSubmit)
                .padding(start = 8.dp)
                .size(48.dp)
        )
    }
}

@Composable
fun TaskItem(
    task: Task,
    onEdit: (String) -> Unit,
    onDelete: () -> Unit
) {
    var isEditing by remember { mutableStateOf(false) }
    var editedText by remember { mutableStateOf(task.title) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .background(Color.LightGray)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isEditing) {
                TextField(
                    value = editedText,
                    onValueChange = { editedText = it },
                    modifier = Modifier.weight(1f),
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Save",
                            modifier = Modifier.clickable {
                                onEdit(editedText)
                                isEditing = false
                            }
                        )
                    }
                )
            } else {
                Text(
                    text = task.title,
                    modifier = Modifier.weight(1f)
                )
            }

            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit",
                modifier = Modifier
                    .clickable { isEditing = true }
                    .padding(horizontal = 8.dp)
            )
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Delete",
                tint = Color.Red,
                modifier = Modifier.clickable { onDelete() }
            )
        }
    }
}